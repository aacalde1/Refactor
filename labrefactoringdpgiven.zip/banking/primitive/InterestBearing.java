package banking.primitive;

public interface InterestBearing
{
	public void accrueInterest();
}
